using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace DynamicIsland.AI;

internal sealed record CodexUsageWindow(double UsedPercent, int DurationMinutes, DateTimeOffset ResetAt)
{
    public double RemainingPercent => Math.Clamp(100.0 - UsedPercent, 0.0, 100.0);
}

internal sealed record CodexUsageSnapshot(CodexUsageWindow? FiveHour, CodexUsageWindow? Weekly);

internal static class CodexUsageReader
{
    public static async Task<CodexUsageSnapshot> ReadAsync(CancellationToken cancellationToken = default)
    {
        string? executable = FindCodexExecutable();
        if (executable == null)
            throw new FileNotFoundException("Codex CLI is not installed.");

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromSeconds(10));
        using var process = new Process
        {
            StartInfo = new ProcessStartInfo(executable)
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardInputEncoding = new UTF8Encoding(false),
                StandardOutputEncoding = new UTF8Encoding(false),
                StandardErrorEncoding = new UTF8Encoding(false)
            }
        };
        process.StartInfo.ArgumentList.Add("app-server");
        process.StartInfo.ArgumentList.Add("--stdio");
        if (!process.Start()) throw new InvalidOperationException("Codex app-server could not start.");

        // Drain diagnostics so a noisy app-server cannot block its stdout RPC.
        Task stderrDrain = process.StandardError.ReadToEndAsync(timeout.Token);
        try
        {
            await SendAsync(process, new
            {
                id = 1,
                method = "initialize",
                @params = new
                {
                    clientInfo = new
                    {
                        name = "dynamic_island_usage",
                        title = "Dynamic Island Usage",
                        version = "0.1.0"
                    }
                }
            });
            using (await WaitForResponseAsync(process, 1, timeout.Token)) { }
            await SendAsync(process, new { method = "initialized" });
            await SendAsync(process, new { id = 2, method = "account/rateLimits/read" });
            using JsonDocument response = await WaitForResponseAsync(process, 2, timeout.Token);
            return ParseSnapshot(response.RootElement);
        }
        finally
        {
            if (!process.HasExited)
            {
                try { process.Kill(entireProcessTree: true); } catch { }
            }
            try { await stderrDrain; } catch { }
        }
    }

    private static async Task SendAsync(Process process, object request)
    {
        await process.StandardInput.WriteLineAsync(JsonSerializer.Serialize(request));
        await process.StandardInput.FlushAsync();
    }

    private static async Task<JsonDocument> WaitForResponseAsync(
        Process process, int requestId, CancellationToken cancellationToken)
    {
        while (true)
        {
            string? line = await process.StandardOutput.ReadLineAsync(cancellationToken);
            if (line == null) throw new IOException("Codex app-server closed before returning usage.");
            JsonDocument message = JsonDocument.Parse(line);
            JsonElement root = message.RootElement;
            if (!root.TryGetProperty("id", out JsonElement id) ||
                id.ValueKind != JsonValueKind.Number || id.GetInt32() != requestId)
            {
                message.Dispose();
                continue;
            }
            if (root.TryGetProperty("error", out JsonElement error) &&
                error.ValueKind == JsonValueKind.Object)
            {
                string detail = error.TryGetProperty("message", out JsonElement text)
                    ? text.GetString() ?? "unknown error" : "unknown error";
                message.Dispose();
                throw new InvalidOperationException(detail);
            }
            return message;
        }
    }

    private static CodexUsageSnapshot ParseSnapshot(JsonElement root)
    {
        if (!root.TryGetProperty("result", out JsonElement result))
            throw new InvalidDataException("Codex usage response has no result.");

        JsonElement bucket;
        if (result.TryGetProperty("rateLimitsByLimitId", out JsonElement buckets) &&
            buckets.ValueKind == JsonValueKind.Object &&
            buckets.TryGetProperty("codex", out JsonElement codex))
            bucket = codex;
        else if (result.TryGetProperty("rateLimits", out JsonElement legacy) &&
                 legacy.ValueKind == JsonValueKind.Object)
            bucket = legacy;
        else
            throw new InvalidDataException("Codex usage is unavailable for this account.");

        var windows = new List<CodexUsageWindow>(2);
        if (bucket.TryGetProperty("primary", out JsonElement primary) &&
            ParseWindow(primary) is { } first) windows.Add(first);
        if (bucket.TryGetProperty("secondary", out JsonElement secondary) &&
            ParseWindow(secondary) is { } second) windows.Add(second);

        // Never label a changed server window as 5 hours or one week.
        CodexUsageWindow? fiveHour = windows.Find(item => item.DurationMinutes == 300);
        CodexUsageWindow? weekly = windows.Find(item => item.DurationMinutes == 10080);
        return new CodexUsageSnapshot(fiveHour, weekly);
    }

    private static CodexUsageWindow? ParseWindow(JsonElement value)
    {
        if (value.ValueKind != JsonValueKind.Object ||
            !value.TryGetProperty("usedPercent", out JsonElement used) ||
            !used.TryGetDouble(out double percent) ||
            !value.TryGetProperty("windowDurationMins", out JsonElement duration) ||
            !duration.TryGetInt32(out int minutes) ||
            !value.TryGetProperty("resetsAt", out JsonElement reset) ||
            !reset.TryGetInt64(out long resetSeconds))
            return null;

        return new CodexUsageWindow(percent, minutes,
            DateTimeOffset.FromUnixTimeSeconds(resetSeconds));
    }

    private static string? FindCodexExecutable()
    {
        string? explicitPath = Environment.GetEnvironmentVariable("CODEX_CLI_PATH");
        if (!string.IsNullOrWhiteSpace(explicitPath) && File.Exists(explicitPath))
            return explicitPath;

        string relative = Path.Combine("node_modules", "@openai", "codex", "node_modules",
            "@openai", "codex-win32-x64", "vendor", "x86_64-pc-windows-msvc", "bin", "codex.exe");
        var prefixes = new List<string>
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "npm"),
            @"D:\npm"
        };
        string? npmPrefix = Environment.GetEnvironmentVariable("NPM_CONFIG_PREFIX");
        if (!string.IsNullOrWhiteSpace(npmPrefix)) prefixes.Insert(0, npmPrefix);
        foreach (string prefix in prefixes)
        {
            string candidate = Path.Combine(prefix, relative);
            if (File.Exists(candidate)) return candidate;
        }

        foreach (string directory in (Environment.GetEnvironmentVariable("PATH") ?? "")
                     .Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            try
            {
                string candidate = Path.Combine(directory, "codex.exe");
                if (File.Exists(candidate)) return candidate;
            }
            catch { }
        }
        return null;
    }
}
