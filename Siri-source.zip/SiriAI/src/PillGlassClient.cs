using System;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Threading;

namespace SiriAi
{
    // Independent live compositor sample for a rounded input capsule.  The
    // capture worker returns already-blurred and displaced pixels, so the WPF
    // window replaces the original backdrop instead of exposing two copies.
    internal sealed class PillGlassClient : IDisposable
    {
        private readonly MemoryMappedFile _memory;
        private readonly MemoryMappedViewAccessor _view;
        private readonly Mutex _mutex;
        private readonly Process _worker;
        private int _lastGeneration = -1;

        internal int Width { get; private set; }
        internal int Height { get; private set; }
        internal bool Ready { get; private set; }

        internal static PillGlassClient TryCreate(int width, int height)
        {
            string path = Environment.GetEnvironmentVariable("SIRI_LIQUID_GLASS_HELPER");
            if (string.IsNullOrEmpty(path))
                path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "runtime", "liquid-glass", "LiquidGlassCapture.exe");
            if (!File.Exists(path)) return null;
            try { return new PillGlassClient(path, width, height); }
            catch (Exception ex) { Log.Write("Pill glass capture unavailable: " + ex.Message); return null; }
        }

        private PillGlassClient(string path, int width, int height)
        {
            Width = Math.Max(32, Math.Min(960, width));
            Height = Math.Max(16, Math.Min(160, height));
            string name = "Local\\SiriPillGlass-" + Process.GetCurrentProcess().Id + "-" + Guid.NewGuid().ToString("N");
            _memory = MemoryMappedFile.CreateNew(name, 64L + (long)Width * Height * 4L);
            _view = _memory.CreateViewAccessor();
            _mutex = new Mutex(false, name + "-lock");
            _worker = Process.Start(new ProcessStartInfo(path,
                Process.GetCurrentProcess().Id + " \"" + name + "\" pill " + Width + " " + Height)
            { UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden });
        }

        internal bool Update(int x, int y, int screenWidth, int screenHeight, bool enabled, int[] pixels)
        {
            if (_worker == null || _worker.HasExited) { Ready = false; return false; }
            if (!_mutex.WaitOne(0)) return false;
            try
            {
                _view.Write(0, x);
                _view.Write(4, y);
                _view.Write(8, screenWidth);
                _view.Write(12, screenHeight);
                _view.Write(16, enabled ? 1 : 0);
                bool ready = enabled && _view.ReadInt32(20) == 1;
                if (ready != Ready) Log.Write("Pill glass independent capture ready=" + ready);
                Ready = ready;
                int generation = _view.ReadInt32(24);
                if (!Ready || generation == _lastGeneration) return false;
                _view.ReadArray(64, pixels, 0, pixels.Length);
                _lastGeneration = generation;
                return true;
            }
            finally { _mutex.ReleaseMutex(); }
        }

        internal void Suspend()
        {
            if (_worker == null || _worker.HasExited) return;
            if (!_mutex.WaitOne(0)) return;
            try { _view.Write(16, 0); Ready = false; }
            finally { _mutex.ReleaseMutex(); }
        }

        public void Dispose()
        {
            if (_worker != null)
            {
                try { if (!_worker.HasExited) _worker.Kill(); } catch { }
                _worker.Dispose();
            }
            _view.Dispose();
            _memory.Dispose();
            _mutex.Dispose();
        }
    }
}
