using System;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Threading;

namespace SiriAi
{
    internal sealed class LiquidGlassPreviewClient : IDisposable
    {
        internal const int Width=348, Height=256;
        private readonly MemoryMappedFile memory;
        private readonly MemoryMappedViewAccessor view;
        private readonly Mutex mutex;
        private readonly Process worker;
        private int lastGeneration=-1;
        internal bool Ready {get;private set;}
        internal static LiquidGlassPreviewClient TryCreate()
        {
            string path=Environment.GetEnvironmentVariable("SIRI_LIQUID_GLASS_HELPER");
            if(string.IsNullOrEmpty(path))
                path=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"runtime","liquid-glass","LiquidGlassCapture.exe");
            if(string.IsNullOrEmpty(path)||!File.Exists(path))return null;
            try{return new LiquidGlassPreviewClient(path);}catch(Exception ex){Log.Write("Liquid glass preview unavailable: "+ex.Message);return null;}
        }
        private LiquidGlassPreviewClient(string path)
        {
            string name="Local\\SiriGlass-"+Process.GetCurrentProcess().Id+"-"+Guid.NewGuid().ToString("N");
            memory=MemoryMappedFile.CreateNew(name,64+Width*Height*4);
            view=memory.CreateViewAccessor();mutex=new Mutex(false,name+"-lock");
            worker=Process.Start(new ProcessStartInfo(path,Process.GetCurrentProcess().Id+" \""+name+"\"")
            {UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden});
        }
        internal bool Update(int x,int y,int width,int height,bool enabled,int[] pixels)
        {
            if(worker==null||worker.HasExited){Ready=false;return false;}
            if(!mutex.WaitOne(0))return false;
            try
            {
                view.Write(0,x);view.Write(4,y);view.Write(8,width);view.Write(12,height);view.Write(16,enabled?1:0);
                bool ready=enabled && view.ReadInt32(20)==1;
                if(ready!=Ready)Log.Write("Liquid glass independent capture ready="+ready);
                Ready=ready;
                int generation=view.ReadInt32(24);
                if(!Ready||generation==lastGeneration)return false;
                view.ReadArray(64,pixels,0,pixels.Length);lastGeneration=generation;return true;
            }
            finally{mutex.ReleaseMutex();}
        }
        public void Dispose()
        {
            if(worker!=null){try{if(!worker.HasExited)worker.Kill();}catch{}worker.Dispose();}
            view.Dispose();memory.Dispose();mutex.Dispose();
        }
    }
}
