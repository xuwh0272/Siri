using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace LiquidGlassWpf
{
    public struct GlassShape
    {
        public double CenterX, CenterY, Width, Height, Radius;
        public GlassShape(double centerX, double centerY, double width, double height, double radius)
        {
            CenterX = centerX; CenterY = centerY; Width = width; Height = height; Radius = radius;
        }
    }

    /// <summary>Uniform-like controls. Defaults are visual demo values, not Apple runtime values.</summary>
    public sealed class GlassOptions
    {
        public double InnerRefractionAmount = 42;
        public double InnerRefractionHeight = 26;
        public double OuterRefractionAmount = -5;
        public double OuterRefractionHeight = 14;
        public double RefractionThreshold0 = -10;
        public double RefractionThreshold1 = 3;
        public double RefractionOpacity = 0.16;
        public double[] DisplacementMatrix = { 1, 0, 0, 1 };
        public double BlurRadius = 1.25;
        public double BlurEdgeRadius = 2;
        public double AberrationAmount = 3.5;
        public double EdgeBleedAmount = 0.15;
        public double EdgeBleedWidth = 13;
        public double ShadowAmount = 0.28;
        public double ShadowRadius = 16;
        public double ShadowOffsetX = 0;
        public double ShadowOffsetY = 5;
        public double HighlightAmount = 0.33;
        public double HighlightWidth = 4;
        public double[] LightDirection = { -0.45, -0.89 };
        public double FaceOpacity = 0.98;
        public double[] Tint = { 255, 255, 255 };
        public double TintAmount = 0.035;
        public double[] FaceColorMatrix = { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0 };
    }

    public static class LiquidGlassRenderer
    {
        private sealed class MipLevel
        {
            public byte[] Data;
            public int Width;
            public int Height;
            public MipLevel(byte[] data, int width, int height)
            { Data = data; Width = width; Height = height; }
        }

        private static double Clamp(double x, double low, double high)
        { return Math.Max(low, Math.Min(high, x)); }
        private static double Saturate(double x) { return Clamp(x, 0, 1); }
        private static double Mix(double a, double b, double t) { return a + (b - a) * t; }
        private static byte ByteValue(double value)
        { return (byte)Math.Round(Clamp(value, 0, 255), MidpointRounding.ToEven); }

        /// <summary>Negative inside, positive outside. Coordinates are pixels.</summary>
        public static double RoundedRectSdf(double x, double y, GlassShape shape)
        {
            double r = Clamp(shape.Radius, 0, Math.Min(shape.Width, shape.Height) / 2);
            double qx = Math.Abs(x - shape.CenterX) - (shape.Width / 2 - r);
            double qy = Math.Abs(y - shape.CenterY) - (shape.Height / 2 - r);
            double ox = Math.Max(qx, 0), oy = Math.Max(qy, 0);
            return Math.Sqrt(ox * ox + oy * oy) + Math.Min(Math.Max(qx, qy), 0) - r;
        }

        /// <summary>Recovered lens curve: 1 - saturate(sqrt(t * (2-t))).</summary>
        public static double LensFalloff(double signedDistance, double inverseHeight)
        {
            double t = Saturate(-signedDistance * inverseHeight);
            return 1 - Saturate(Math.Sqrt(t * (2 - t)));
        }

        private static double[] Gradient(double x, double y, GlassShape shape)
        {
            double dx = RoundedRectSdf(x + 0.5, y, shape) - RoundedRectSdf(x - 0.5, y, shape);
            double dy = RoundedRectSdf(x, y + 0.5, shape) - RoundedRectSdf(x, y - 0.5, shape);
            double length = Math.Sqrt(dx * dx + dy * dy);
            return length > 1e-6 ? new[] { dx / length, dy / length } : new[] { 0.0, -1.0 };
        }

        private static System.Collections.Generic.List<MipLevel> BuildMipChain(byte[] source, int width, int height)
        {
            var levels = new System.Collections.Generic.List<MipLevel>();
            levels.Add(new MipLevel(source, width, height));
            while ((width > 1 || height > 1) && levels.Count < 9)
            {
                MipLevel parent = levels[levels.Count - 1];
                int w = Math.Max(1, (width + 1) / 2), h = Math.Max(1, (height + 1) / 2);
                byte[] data = new byte[checked(w * h * 4)];
                for (int y = 0; y < h; y++) for (int x = 0; x < w; x++)
                {
                    double[] sum = new double[4]; int count = 0;
                    for (int yy = 0; yy < 2; yy++) for (int xx = 0; xx < 2; xx++)
                    {
                        int sx = x * 2 + xx, sy = y * 2 + yy;
                        if (sx >= width || sy >= height) continue;
                        int i = (sy * width + sx) * 4;
                        for (int c = 0; c < 4; c++) sum[c] += parent.Data[i + c];
                        count++;
                    }
                    int dest = (y * w + x) * 4;
                    for (int c = 0; c < 4; c++) data[dest + c] = ByteValue(sum[c] / count);
                }
                levels.Add(new MipLevel(data, w, h)); width = w; height = h;
            }
            return levels;
        }

        private static double[] Bilinear(MipLevel level, double x, double y, int fullWidth, int fullHeight)
        {
            double px = Clamp((x + 0.5) * level.Width / fullWidth - 0.5, 0, level.Width - 1);
            double py = Clamp((y + 0.5) * level.Height / fullHeight - 0.5, 0, level.Height - 1);
            int x0 = (int)Math.Floor(px), y0 = (int)Math.Floor(py);
            int x1 = Math.Min(x0 + 1, level.Width - 1), y1 = Math.Min(y0 + 1, level.Height - 1);
            double tx = px - x0, ty = py - y0;
            double[] result = new double[4];
            for (int c = 0; c < 4; c++)
            {
                double a = Mix(level.Data[(y0 * level.Width + x0) * 4 + c],
                    level.Data[(y0 * level.Width + x1) * 4 + c], tx);
                double b = Mix(level.Data[(y1 * level.Width + x0) * 4 + c],
                    level.Data[(y1 * level.Width + x1) * 4 + c], tx);
                result[c] = Mix(a, b, ty);
            }
            return result;
        }

        private static double[] SampleLod(System.Collections.Generic.List<MipLevel> levels,
            double x, double y, double lod, int width, int height)
        {
            double l = Clamp(lod, 0, levels.Count - 1); int low = (int)Math.Floor(l);
            int high = Math.Min(low + 1, levels.Count - 1);
            double[] a = Bilinear(levels[low], x, y, width, height);
            if (low == high) return a;
            double[] b = Bilinear(levels[high], x, y, width, height);
            for (int c = 0; c < 4; c++) a[c] = Mix(a[c], b[c], l - low);
            return a;
        }

        private static double[] Dispersion(System.Collections.Generic.List<MipLevel> levels,
            double x, double y, double tangentX, double tangentY, double amount,
            double lod, int width, int height)
        {
            if (amount <= 0.001) return SampleLod(levels, x, y, lod, width, height);
            // Seven positions approximate the AIR aberrate_texture channel split.
            double[][] taps = new double[7][];
            for (int i = -3; i <= 3; i++)
                taps[i + 3] = SampleLod(levels, x + tangentX * amount * i / 3,
                    y + tangentY * amount * i / 3, lod, width, height);
            return new[] {
                (taps[4][0] + taps[5][0] + taps[6][0]) / 3,
                (taps[2][1] + taps[3][1] + taps[4][1]) / 3,
                (taps[0][2] + taps[1][2] + taps[2][2]) / 3,
                taps[3][3]
            };
        }

        /// <summary>
        /// Render an RGBA effect from BGRA32 pixels, returning a new BGRA32 buffer.
        /// This core method is also usable in non-UI tests.
        /// </summary>
        public static byte[] RenderPixels(byte[] sourceBgra, int width, int height,
            GlassShape shape, GlassOptions options = null)
        {
            if (width < 1 || height < 1 || sourceBgra == null ||
                sourceBgra.Length != checked(width * height * 4))
                throw new ArgumentException("Invalid BGRA32 buffer", "sourceBgra");
            if (shape.Width <= 0 || shape.Height <= 0) throw new ArgumentException("Invalid glass shape", "shape");
            GlassOptions o = options ?? new GlassOptions();
            if (o.DisplacementMatrix == null || o.DisplacementMatrix.Length != 4 ||
                o.LightDirection == null || o.LightDirection.Length != 2 ||
                o.Tint == null || o.Tint.Length != 3 ||
                o.FaceColorMatrix == null || o.FaceColorMatrix.Length != 12)
                throw new ArgumentException("Invalid glass option array", "options");

            byte[] source = new byte[sourceBgra.Length];
            for (int i = 0; i < source.Length; i += 4)
            {
                source[i] = sourceBgra[i + 2]; source[i + 1] = sourceBgra[i + 1];
                source[i + 2] = sourceBgra[i]; source[i + 3] = sourceBgra[i + 3];
            }
            byte[] output = (byte[])source.Clone();
            var levels = BuildMipChain(source, width, height);
            int margin = (int)Math.Ceiling(Math.Max(o.ShadowRadius * 2.5 + Math.Abs(o.ShadowOffsetY),
                Math.Max(Math.Abs(o.OuterRefractionAmount) + 4, o.EdgeBleedWidth + 4)));
            int xmin = (int)Clamp(Math.Floor(shape.CenterX - shape.Width / 2 - margin), 0, width - 1);
            int xmax = (int)Clamp(Math.Ceiling(shape.CenterX + shape.Width / 2 + margin), 0, width - 1);
            int ymin = (int)Clamp(Math.Floor(shape.CenterY - shape.Height / 2 - margin), 0, height - 1);
            int ymax = (int)Clamp(Math.Ceiling(shape.CenterY + shape.Height / 2 + margin), 0, height - 1);
            double lightLength = Math.Sqrt(o.LightDirection[0] * o.LightDirection[0] +
                o.LightDirection[1] * o.LightDirection[1]);
            if (lightLength == 0) lightLength = 1;
            double lightX = o.LightDirection[0] / lightLength, lightY = o.LightDirection[1] / lightLength;

            for (int y = ymin; y <= ymax; y++) for (int x = xmin; x <= xmax; x++)
            {
                double d = RoundedRectSdf(x + 0.5, y + 0.5, shape);
                double sd = RoundedRectSdf(x + 0.5 - o.ShadowOffsetX,
                    y + 0.5 - o.ShadowOffsetY, shape);
                int i = (y * width + x) * 4;
                double shadow = o.ShadowAmount * Math.Exp(-Math.Pow(Math.Max(sd, 0) /
                    Math.Max(o.ShadowRadius, 0.001), 2)) * Saturate(sd / 2 + 0.5) *
                    (1 - Saturate(0.5 - d));
                if (shadow > 0.0001)
                    for (int c = 0; c < 3; c++) output[i + c] = ByteValue(output[i + c] * (1 - shadow));
                double coverage = Saturate(0.5 - d); // fwidth≈1 in pixel space
                if (coverage <= 0) continue;
                double[] grad = Gradient(x + 0.5, y + 0.5, shape);
                double gx = grad[0], gy = grad[1];
                double mx = o.DisplacementMatrix[0] * gx + o.DisplacementMatrix[1] * gy;
                double my = o.DisplacementMatrix[2] * gx + o.DisplacementMatrix[3] * gy;
                double inner = o.InnerRefractionAmount * LensFalloff(d,
                    1 / Math.Max(o.InnerRefractionHeight, 0.001));
                double outer = o.OuterRefractionAmount * LensFalloff(d,
                    1 / Math.Max(o.OuterRefractionHeight, 0.001));
                double thresholdWidth = o.RefractionThreshold1 - o.RefractionThreshold0;
                double outerWeight = Saturate((d - o.RefractionThreshold0) /
                    (Math.Abs(thresholdWidth) < 1e-6 ? 1e-6 : thresholdWidth)) * o.RefractionOpacity;
                double shift = Mix(inner, outer, outerWeight);
                double sx = x + mx * shift, sy = y + my * shift;
                double edge = LensFalloff(d, 1 / Math.Max(o.InnerRefractionHeight, 0.001));
                double radius = Math.Max(1, o.BlurRadius + o.BlurEdgeRadius * edge);
                double lod = Math.Max(0, Math.Log(radius, 2));
                double[] sampled = Dispersion(levels, sx, sy, -my, mx,
                    o.AberrationAmount * edge, lod, width, height);
                double[] rgb = new double[3];
                for (int row = 0; row < 3; row++)
                {
                    int m = row * 4;
                    rgb[row] = o.FaceColorMatrix[m] * sampled[0] +
                        o.FaceColorMatrix[m + 1] * sampled[1] +
                        o.FaceColorMatrix[m + 2] * sampled[2] +
                        o.FaceColorMatrix[m + 3] * 255;
                }
                double bleed = o.EdgeBleedAmount * Math.Exp(-Math.Abs(d) /
                    Math.Max(o.EdgeBleedWidth, 0.001));
                if (bleed > 0.001)
                {
                    double[] nearby = SampleLod(levels, x + gx * o.EdgeBleedWidth * 0.45,
                        y + gy * o.EdgeBleedWidth * 0.45, lod + 1, width, height);
                    for (int c = 0; c < 3; c++) rgb[c] = Mix(rgb[c], nearby[c], bleed);
                }
                double rim = Math.Exp(-Math.Pow(d / Math.Max(o.HighlightWidth, 0.001), 2));
                double facing = Math.Max(0, gx * lightX + gy * lightY);
                double highlight = o.HighlightAmount * rim * (0.3 + 0.7 * facing);
                for (int c = 0; c < 3; c++)
                {
                    double tinted = Mix(rgb[c], o.Tint[c], o.TintAmount);
                    double lit = Mix(tinted, 255, highlight);
                    output[i + c] = ByteValue(Mix(output[i + c], lit, coverage * o.FaceOpacity));
                }
                output[i + 3] = source[i + 3];
            }
            byte[] result = new byte[output.Length];
            for (int i = 0; i < output.Length; i += 4)
            {
                result[i] = output[i + 2]; result[i + 1] = output[i + 1];
                result[i + 2] = output[i]; result[i + 3] = output[i + 3];
            }
            return result;
        }

        public static WriteableBitmap Render(BitmapSource background,
            GlassShape shape, GlassOptions options = null)
        {
            if (background == null) throw new ArgumentNullException("background");
            BitmapSource source = background.Format == PixelFormats.Bgra32 ? background :
                new FormatConvertedBitmap(background, PixelFormats.Bgra32, null, 0);
            int width = source.PixelWidth, height = source.PixelHeight, stride = checked(width * 4);
            byte[] pixels = new byte[checked(stride * height)];
            source.CopyPixels(pixels, stride, 0);
            byte[] result = RenderPixels(pixels, width, height, shape, options);
            WriteableBitmap bitmap = new WriteableBitmap(width, height,
                background.DpiX > 0 ? background.DpiX : 96,
                background.DpiY > 0 ? background.DpiY : 96, PixelFormats.Bgra32, null);
            bitmap.WritePixels(new Int32Rect(0, 0, width, height), result, stride, 0);
            bitmap.Freeze();
            return bitmap;
        }

        /// <summary>
        /// Returns a transparent, premultiplied BGRA overlay suitable for an Image
        /// placed above the original background. Re-render when that background changes.
        /// </summary>
        public static WriteableBitmap RenderOverlay(BitmapSource background,
            GlassShape shape, GlassOptions options = null)
        {
            if (background == null) throw new ArgumentNullException("background");
            BitmapSource source = background.Format == PixelFormats.Bgra32 ? background :
                new FormatConvertedBitmap(background, PixelFormats.Bgra32, null, 0);
            int width = source.PixelWidth, height = source.PixelHeight, stride = checked(width * 4);
            byte[] input = new byte[checked(stride * height)];
            source.CopyPixels(input, stride, 0);
            byte[] composed = RenderPixels(input, width, height, shape, options);
            GlassOptions o = options ?? new GlassOptions();
            byte[] overlay = new byte[input.Length];
            int margin = (int)Math.Ceiling(Math.Max(o.ShadowRadius * 2.5 + Math.Abs(o.ShadowOffsetY),
                Math.Max(Math.Abs(o.OuterRefractionAmount) + 4, o.EdgeBleedWidth + 4)));
            int xmin = (int)Clamp(Math.Floor(shape.CenterX - shape.Width / 2 - margin), 0, width - 1);
            int xmax = (int)Clamp(Math.Ceiling(shape.CenterX + shape.Width / 2 + margin), 0, width - 1);
            int ymin = (int)Clamp(Math.Floor(shape.CenterY - shape.Height / 2 - margin), 0, height - 1);
            int ymax = (int)Clamp(Math.Ceiling(shape.CenterY + shape.Height / 2 + margin), 0, height - 1);
            for (int y = ymin; y <= ymax; y++) for (int x = xmin; x <= xmax; x++)
            {
                double d = RoundedRectSdf(x + 0.5, y + 0.5, shape);
                double sd = RoundedRectSdf(x + 0.5 - o.ShadowOffsetX,
                    y + 0.5 - o.ShadowOffsetY, shape);
                double shadow = o.ShadowAmount * Math.Exp(-Math.Pow(Math.Max(sd, 0) /
                    Math.Max(o.ShadowRadius, 0.001), 2)) * Saturate(sd / 2 + 0.5) *
                    (1 - Saturate(0.5 - d));
                if (shadow <= 0.0001) shadow = 0;
                double face = Saturate(0.5 - d) * o.FaceOpacity;
                double alpha = Saturate(shadow + face * (1 - shadow));
                if (alpha <= 0) continue;
                int i = (y * width + x) * 4;
                overlay[i + 3] = ByteValue(alpha * 255);
                for (int c = 0; c < 3; c++)
                    overlay[i + c] = ByteValue(composed[i + c] - input[i + c] * (1 - alpha));
            }
            WriteableBitmap bitmap = new WriteableBitmap(width, height,
                background.DpiX > 0 ? background.DpiX : 96,
                background.DpiY > 0 ? background.DpiY : 96, PixelFormats.Pbgra32, null);
            bitmap.WritePixels(new Int32Rect(0, 0, width, height), overlay, stride, 0);
            bitmap.Freeze();
            return bitmap;
        }
    }
}

