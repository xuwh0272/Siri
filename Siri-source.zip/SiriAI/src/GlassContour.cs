using System;

namespace SiriAi
{
    // A true stadium: two horizontal straight segments joined tangentially
    // to left/right semicircles. Shared by the material and optical mask.
    internal static class GlassContour
    {
        internal static double Radius(double nx, double ny, double aspect)
        {
            double side = Math.Max(0.0, Math.Abs(nx) * aspect - (aspect - 1.0));
            return Math.Sqrt(side * side + ny * ny);
        }
    }
}
