using System;

namespace SiriAi
{
    // A true stadium: two horizontal straight segments joined tangentially
    // to left/right semicircles. Shared by the material and optical mask.
    internal static class GlassContour
    {
        internal static double Radius(double nx, double ny, double aspect)
        {
            double side = Math.Max(0.0, Math.Abs(nx) * aspect - (aspect - 1.0));
            return Math.Sqrt(side * side + ny * ny);
        }

        // Both the painted material and the captured background must disappear
        // across the same subpixel-width rim. A different cutoff on either layer
        // leaves a visible sliver where the black cap meets the live glass.
        internal static double EdgeCoverage(double radius, int sampleHeight)
        {
            double depth = (1.0 - radius) * (sampleHeight - 1) * 0.5;
            double t = Math.Max(0.0, Math.Min(1.0, depth / 0.8));
            return t * t * (3.0 - 2.0 * t);
        }
    }
}
