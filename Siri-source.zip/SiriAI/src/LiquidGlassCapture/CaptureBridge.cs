using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Runtime.InteropServices;

namespace SiriAi;

// Window-only capture avoids feeding the overlay back into its own lens.
// Composite visible windows in screen z-order before applying the optical map.
internal static class CaptureBridge
{
    internal const int Width=348, Height=256;
    private static readonly HashSet<int> companions=new();
    private sealed record Frame(int[] Pixels,int Width,int Height,int[] Bounds);
    private sealed class Layer : IDisposable
    {
        internal IntPtr Handle;
        internal WindowCapture Capture;
        internal Frame Latest;
        internal Rect Bounds;
        public void Dispose() { Capture?.Dispose(); }
    }
    internal static void Run(int parentId,string name,int width=Width,int height=Height,bool pill=false)
    {
        int Width=width, Height=height;
        using var parent=Process.GetProcessById(parentId);
        using var memory=MemoryMappedFile.OpenExisting(name);
        using var view=memory.CreateViewAccessor();
        using var mutex=Mutex.OpenExisting(name+"-lock");
        var orbOptics=pill?null:new LiquidGlassOptics(Width,Height);
        var pillOptics=pill?new PillGlassOptics(Width,Height):null;
        byte[] coverage=pill?pillOptics!.Coverage:orbOptics!.Coverage;
        float[] offsetX=pill?pillOptics!.OffsetX:orbOptics!.OffsetX;
        float[] offsetY=pill?pillOptics!.OffsetY:orbOptics!.OffsetY;
        var layers=new Dictionary<IntPtr,Layer>();
        var retry=new Dictionary<IntPtr,long>();
        var scene=new List<(IntPtr Handle,Rect Bounds)>();
        foreach(string processName in new[]{"DynamicIsland","Siri AI"})
            foreach(var p in Process.GetProcessesByName(processName)) {companions.Add(p.Id);p.Dispose();}
        int[] source=new int[Width*Height],output=new int[source.Length];
        bool[] covered=new bool[source.Length];
        bool[] usable=new bool[source.Length];
        long nextScene=0;
        int generation=0;
        try
        {
            while(!parent.HasExited)
            {
                int x,y,w,h,enabled;
                mutex.WaitOne();
                try{x=view.ReadInt32(0);y=view.ReadInt32(4);w=view.ReadInt32(8);h=view.ReadInt32(12);enabled=view.ReadInt32(16);}
                finally{mutex.ReleaseMutex();}
                if(Environment.TickCount64>=nextScene)
                {
                    nextScene=Environment.TickCount64+100;
                    scene=enabled!=0 && w>0 && h>0 ? FindScene(parentId,x,y,w,h) : new();
                    var handles=scene.Select(s=>s.Handle).ToHashSet();
                    foreach(var key in layers.Keys.Where(k=>!handles.Contains(k)).ToArray()) {layers[key].Dispose();layers.Remove(key);}
                    foreach(var item in scene)
                    {
                        if(layers.TryGetValue(item.Handle,out var existing)){existing.Bounds=item.Bounds;Volatile.Write(ref existing.Capture.CropScreen,new[]{x,y,w,h});continue;}
                        if(retry.TryGetValue(item.Handle,out long due)&&Environment.TickCount64<due)continue;
                        var layer=new Layer{Handle=item.Handle,Bounds=item.Bounds};
                        try
                        {
                            layer.Capture=new WindowCapture(item.Handle);
                            layer.Capture.CropScreen=new[]{x,y,w,h};
                            layer.Capture.Frame+=(pixels,fw,fh)=>Volatile.Write(ref layer.Latest,new Frame(pixels,fw,fh,layer.Capture.PublishedBounds));
                            layer.Capture.Start();layers.Add(item.Handle,layer);
                        }
                        catch (Exception ex)
                        {
                            layer.Dispose();
                            retry[item.Handle]=Environment.TickCount64+3000;
                            try
                            {
                                string path=Path.Combine(AppContext.BaseDirectory,"capture-errors.log");
                                GetWindowThreadProcessId(item.Handle,out int failedPid);
                                string processName;
                                try { using var failedProcess=Process.GetProcessById(failedPid); processName=failedProcess.ProcessName; }
                                catch { processName="unknown"; }
                                string line=$"{DateTime.Now:O} hwnd=0x{item.Handle.ToInt64():X} pid={failedPid} process={processName} hr=0x{ex.HResult:X8} {ex.GetType().Name}: {ex.Message}{Environment.NewLine}";
                                File.AppendAllText(path,line);
                            }
                            catch { }
                        }
                    }
                }
                Array.Clear(source);Array.Clear(covered);
                // Back to front, respecting the background window's alpha.
                for(int n=scene.Count-1;n>=0;n--)
                {
                    if(!layers.TryGetValue(scene[n].Handle,out var layer))continue;
                    var frame=Volatile.Read(ref layer.Latest);
                    if(frame==null)continue;
                    var r=new Rect{left=frame.Bounds[0],top=frame.Bounds[1],right=frame.Bounds[2],bottom=frame.Bounds[3]};
                    if(r.right<=r.left||r.bottom<=r.top)continue;
                    for(int py=0;py<Height;py++)for(int px=0;px<Width;px++)
                    {
                        double sx=x+(px+0.5)*w/Width,sy=y+(py+0.5)*h/Height;
                        if(sx<r.left||sx>=r.right||sy<r.top||sy>=r.bottom)continue;
                        int bx=Math.Clamp((int)((sx-r.left)*frame.Width/(r.right-r.left)),0,frame.Width-1);
                        int by=Math.Clamp((int)((sy-r.top)*frame.Height/(r.bottom-r.top)),0,frame.Height-1);
                        int p=frame.Pixels[by*frame.Width+bx],a=(int)((uint)p>>24),i=py*Width+px;
                        if(a==0)continue;
                        if(a>=254){source[i]=p;covered[i]=true;}
                        else
                        {
                            // WGC pixels are premultiplied BGRA.
                            int old=source[i],ia=255-a;
                            int red=Math.Min(255,((p>>16)&255)+((old>>16)&255)*ia/255);
                            int green=Math.Min(255,((p>>8)&255)+((old>>8)&255)*ia/255);
                            int blue=Math.Min(255,(p&255)+(old&255)*ia/255);
                            source[i]=unchecked((int)0xff000000)|red<<16|green<<8|blue;
                        }
                    }
                }
                int requiredPixels=0,usablePixels=0;
                // A single missing desktop/window pixel must not switch off the
                // entire glass layer. Keep valid refracted pixels and leave the
                // uncovered ones transparent for the native lens underneath.
                for(int py=0;py<Height;py++)for(int px=0;px<Width;px++)
                {
                    int i=py*Width+px;
                    usable[i]=false;
                    if(coverage[i]==0)continue;
                    requiredPixels++;
                    bool complete=true;
                    for(int channel=0;channel<3;channel++)
                    {
                        double scale=pill?0.94+channel*0.06:0.97+channel*0.03;
                        int sx=Math.Clamp((int)(px+offsetX[i]*scale),0,Width-2);
                        int sy=Math.Clamp((int)(py+offsetY[i]*scale),0,Height-2);
                        int j=sy*Width+sx;
                        if(!covered[j]||!covered[j+1]||!covered[j+Width]||!covered[j+Width+1]){complete=false;break;}
                    }
                    if(complete){usable[i]=true;usablePixels++;}
                }
                bool ready=enabled!=0 && usablePixels>0;
                if(ready)
                {
                    if(pill)pillOptics!.Render(source,output);
                    else orbOptics!.Render(source,output);
                    for(int i=0;i<output.Length;i++)if(!usable[i])output[i]=0;
                }
                if(mutex.WaitOne(0))
                {
                    try
                    {
                        if(ready){view.WriteArray(64,output,0,output.Length);view.Write(24,++generation);}
                        view.Write(20,ready?1:0);
                        view.Write(28,scene.Count);
                        view.Write(32,requiredPixels);
                        view.Write(36,usablePixels);
                        view.Write(40,layers.Count);
                    }
                    finally{mutex.ReleaseMutex();}
                }
                Thread.Sleep(16);
            }
        }
        finally{foreach(var layer in layers.Values)layer.Dispose();}
    }
    private static List<(IntPtr Handle,Rect Bounds)> FindScene(int parent,int x,int y,int w,int h)
    {
        var result=new List<(IntPtr,Rect)>();
        int fullCoverCount=0;
        EnumWindows((window,data)=>
        {
            GetWindowThreadProcessId(window,out int pid);
            if(pid==parent||pid==Environment.ProcessId||companions.Contains(pid)||!IsWindowVisible(window)||IsIconic(window))return true;
            DwmGetWindowAttribute(window,14,out int cloaked,4);
            if(cloaked!=0||DwmGetWindowAttribute(window,9,out Rect r,16)!=0)return true;
            if(r.right<=x||r.left>=x+w||r.bottom<=y||r.top>=y+h)return true;
            result.Add((window,r));
            // Some full-screen utility overlays (notably screenshot tools) are
            // visible but reject GraphicsCaptureItem.CreateForWindow. Keep the
            // windows behind them as backup sources instead of letting one
            // uncapturable cover suppress the entire refracted background.
            if(r.left<=x&&r.top<=y&&r.right>=x+w&&r.bottom>=y+h)fullCoverCount++;
            return result.Count<6 && fullCoverCount<3;
        },IntPtr.Zero);
        return result;
    }
    [StructLayout(LayoutKind.Sequential)]private struct Rect {public int left,top,right,bottom;}
    private delegate bool EnumProc(IntPtr window,IntPtr data);
    [DllImport("user32.dll")]private static extern bool EnumWindows(EnumProc proc,IntPtr data);
    [DllImport("user32.dll")]private static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")]private static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")]private static extern int GetWindowThreadProcessId(IntPtr h,out int pid);
    [DllImport("dwmapi.dll")]private static extern int DwmGetWindowAttribute(IntPtr h,int attribute,out Rect r,int size);
    [DllImport("dwmapi.dll")]private static extern int DwmGetWindowAttribute(IntPtr h,int attribute,out int value,int size);
}
