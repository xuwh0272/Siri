using System.Runtime.InteropServices;
using Windows.Graphics.Capture;
using Windows.Graphics.DirectX;
using Windows.Graphics.DirectX.Direct3D11;
using WinRT;

namespace SiriAi;

// Capture one underlying HWND rather than the monitor: overlay pixels can never
// enter its input. No window hiding, screen exclusion affinity or privacy changes.
internal sealed class WindowCapture : IDisposable
{
    private readonly IDirect3DDevice device;
    private readonly Direct3D11CaptureFramePool pool;
    private readonly GraphicsCaptureSession session;
    private readonly GpuReadback readback;
    private readonly IntPtr window;
    internal int[] CropScreen;
    internal int[] PublishedBounds;
    private int busy;
    private volatile bool stopped;
    public event Action<int[], int, int> Frame;
    public event Action<Exception> Failed;

    internal WindowCapture(IntPtr hwnd)
    {
        window=hwnd;
        Marshal.ThrowExceptionForHR(D3D11CreateDevice(IntPtr.Zero, 1, IntPtr.Zero, 0x20,
            IntPtr.Zero, 0, 7, out var native, out _, out var context));
        try
        {
            readback=new GpuReadback(native,context);
            var iid = new Guid("54EC77FA-1377-44E6-8C32-88FD5F44C84C");
            Marshal.ThrowExceptionForHR(Marshal.QueryInterface(native, ref iid, out var dxgi));
            try
            {
                Marshal.ThrowExceptionForHR(CreateDirect3D11DeviceFromDXGIDevice(dxgi, out var abi));
                try { device = MarshalInterface<IDirect3DDevice>.FromAbi(abi); }
                finally { Marshal.Release(abi); }
            }
            finally { Marshal.Release(dxgi); }
        }
        finally { Marshal.Release(context); Marshal.Release(native); }
        var interop = GraphicsCaptureItem.As<ICaptureInterop>();
        var itemIid = new Guid("79C3F95B-31F7-4EC2-A464-632EF5D30760");
        var pointer = interop.CreateForWindow(hwnd, in itemIid);
        GraphicsCaptureItem item;
        try { item = GraphicsCaptureItem.FromAbi(pointer); }
        finally { Marshal.Release(pointer); }
        pool = Direct3D11CaptureFramePool.CreateFreeThreaded(device, DirectXPixelFormat.B8G8R8A8UIntNormalized, 2, item.Size);
        session = pool.CreateCaptureSession(item);
        session.IsCursorCaptureEnabled = false;
        if (BorderlessCapture.Allowed) session.IsBorderRequired = false;
        pool.FrameArrived += OnFrame;
    }

    internal void Start() { session.StartCapture(); }

    private void OnFrame(Direct3D11CaptureFramePool sender, object args)
    {
        if (stopped || Interlocked.Exchange(ref busy, 1) != 0) return;
        try
        {
            var frame = sender.TryGetNextFrame();
            if (frame == null) return;
            // Consume the newest available frame, not a growing stale queue.
            for(int n=0;n<2;n++){var newer=sender.TryGetNextFrame();if(newer==null)break;frame.Dispose();frame=newer;}
            using(frame)
            {
                int fw=frame.ContentSize.Width,fh=frame.ContentSize.Height;
                if(fw<1||fh<1)return;
                if(DwmGetWindowAttribute(window,9,out Rect bounds,16)!=0)return;
                int left=0,top=0,right=fw,bottom=fh;
                var crop=Volatile.Read(ref CropScreen);
                if(crop!=null && bounds.Right>bounds.Left && bounds.Bottom>bounds.Top)
                {
                    left=Math.Clamp((crop[0]-bounds.Left)*fw/(bounds.Right-bounds.Left),0,fw);
                    top=Math.Clamp((crop[1]-bounds.Top)*fh/(bounds.Bottom-bounds.Top),0,fh);
                    right=Math.Clamp((int)Math.Ceiling((crop[0]+crop[2]-bounds.Left)*(double)fw/(bounds.Right-bounds.Left)),0,fw);
                    bottom=Math.Clamp((int)Math.Ceiling((crop[1]+crop[3]-bounds.Top)*(double)fh/(bounds.Bottom-bounds.Top)),0,fh);
                }
                if(right<=left||bottom<=top)return;
                int[] pixels=readback.Read(frame.Surface,left,top,right-left,bottom-top);
                PublishedBounds=new[]{bounds.Left+left*(bounds.Right-bounds.Left)/fw,bounds.Top+top*(bounds.Bottom-bounds.Top)/fh,
                    bounds.Left+right*(bounds.Right-bounds.Left)/fw,bounds.Top+bottom*(bounds.Bottom-bounds.Top)/fh};
                if(!stopped)Frame?.Invoke(pixels,right-left,bottom-top);
            }
        }
        catch (Exception ex) { if (!stopped) Failed?.Invoke(ex); }
        finally { Interlocked.Exchange(ref busy, 0); }
    }

    public void Dispose()
    {
        stopped = true;
        pool.FrameArrived -= OnFrame;
        session.Dispose();
        // An in-flight asynchronous read owns a frame until it completes.
        SpinWait.SpinUntil(() => Volatile.Read(ref busy) == 0, 2000);
        pool.Dispose(); readback.Dispose(); device.Dispose();
    }

    [ComImport, Guid("3628E81B-3CAC-4C60-B7F4-23CE0E0C3356"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface ICaptureInterop
    {
        IntPtr CreateForWindow(IntPtr window, in Guid iid);
        IntPtr CreateForMonitor(IntPtr monitor, in Guid iid);
    }
    [DllImport("d3d11.dll")] private static extern int D3D11CreateDevice(IntPtr adapter, int type, IntPtr software, uint flags,
        IntPtr levels, uint levelCount, uint sdk, out IntPtr device, out int level, out IntPtr context);
    [DllImport("d3d11.dll")] private static extern int CreateDirect3D11DeviceFromDXGIDevice(IntPtr dxgi, out IntPtr device);
    [StructLayout(LayoutKind.Sequential)]private struct Rect{public int Left,Top,Right,Bottom;}
    [DllImport("dwmapi.dll")]private static extern int DwmGetWindowAttribute(IntPtr h,int attribute,out Rect rect,int size);
}
