using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Runtime.InteropServices;

namespace SiriAi;

internal static class Program
{
    [STAThread]
    private static void Main(string[] args)
    {
        if (args.Length == 1 && args[0] == "--request-borderless")
        {
            var permissionApp = new Application { ShutdownMode = ShutdownMode.OnExplicitShutdown };
            permissionApp.Startup += async delegate
            {
                await BorderlessCapture.RequestAsync();
                permissionApp.Shutdown(BorderlessCapture.Allowed ? 0 : 2);
            };
            permissionApp.Run();
            return;
        }
        if (args.Length == 2)
        {
            BorderlessCapture.RestorePermission();
            CaptureBridge.Run(int.Parse(args[0]), args[1]); return;
        }
        if (args.Length == 5 && args[2] == "pill")
        {
            BorderlessCapture.RestorePermission();
            CaptureBridge.Run(int.Parse(args[0]), args[1], int.Parse(args[3]), int.Parse(args[4]), true);
            return;
        }
        var app = new Application();
        var grid = new Grid { Background = Brushes.WhiteSmoke };
        var canvas = new Canvas(); grid.Children.Add(canvas);
        for (int i=0;i<800;i+=24)
        {
            canvas.Children.Add(new System.Windows.Shapes.Line { X1=i,Y1=0,X2=i,Y2=400,Stroke=Brushes.DimGray,StrokeThickness=1 });
            canvas.Children.Add(new System.Windows.Shapes.Line { X1=0,Y1=i,X2=800,Y2=i,Stroke=Brushes.DimGray,StrokeThickness=1 });
        }
        var label = new TextBlock { Text="LIVE BACKGROUND 0123456789",FontSize=28,Foreground=Brushes.DarkBlue,Margin=new Thickness(40,240,0,0) };
        grid.Children.Add(label);
        var background = new Window {Title="Siri Liquid Glass test background",Width=800,Height=400,Left=100,Top=250,Content=grid};
        var image = new Image { Stretch=Stretch.Fill };
        var overlay = new Window {Title="Siri Liquid Glass optical test",Width=348,Height=256,Left=300,Top=320,
            WindowStyle=WindowStyle.None,AllowsTransparency=true,Background=Brushes.Transparent,Topmost=true,Content=image};
        WindowCapture capture=null;
        var clock=Stopwatch.StartNew();
        int count=0,pending=0; long changed=0; int[] previous=null;
        RectPx sourceBounds=default, targetBounds=default;
        var bitmap = new WriteableBitmap(348,256,96,96,PixelFormats.Bgra32,null); image.Source=bitmap;
        var optics = new LiquidGlassOptics(348,256);
        var log = Path.Combine(AppContext.BaseDirectory,"capture-test.log");
        app.Startup += delegate
        {
            background.Show(); overlay.Show();
            DwmGetWindowAttribute(new WindowInteropHelper(background).Handle,9,out sourceBounds,16);
            DwmGetWindowAttribute(new WindowInteropHelper(overlay).Handle,9,out targetBounds,16);
            // The test takes real compositor pixels from a separate window.
            // Its moving label proves we are not using a frozen screenshot.
            var move=new DispatcherTimer {Interval=TimeSpan.FromMilliseconds(16)};
            move.Tick += delegate { label.RenderTransform=new TranslateTransform(Math.Sin(clock.Elapsed.TotalSeconds)*65,0); };
            move.Start();
            try
            {
                capture=new WindowCapture(new WindowInteropHelper(background).Handle);
                capture.Failed += ex=>File.AppendAllText(log,ex+Environment.NewLine);
                capture.Frame += (pixels,w,h)=>
                {
                    if(Interlocked.Exchange(ref pending,1)!=0) return;
                    int[] source=new int[348*256],result=new int[source.Length];
                    // Match the actual compositor coordinates and DPI. Cropping
                    // relative to guessed client bounds displaces the entire copy.
                    for(int y=0;y<256;y++) for(int x=0;x<348;x++)
                    {
                        int sx=Math.Clamp((int)((targetBounds.left-sourceBounds.left+(x+0.5)*(targetBounds.right-targetBounds.left)/348.0)*w/(sourceBounds.right-sourceBounds.left)),0,w-1);
                        int sy=Math.Clamp((int)((targetBounds.top-sourceBounds.top+(y+0.5)*(targetBounds.bottom-targetBounds.top)/256.0)*h/(sourceBounds.bottom-sourceBounds.top)),0,h-1);
                        source[y*348+x]=pixels[sy*w+sx];
                    }
                    optics.Render(source,result);
                    // Match Siri's opaque upper cap so the diagnostic view does
                    // not show an unrefracted copy above the lower glass layer.
                    for(int py=0;py<256;py++) for(int px=0;px<348;px++)
                    {
                        double nx=(px-173.5)/173.5,ny=(py-127.5)/127.5;
                        double q=GlassContour.Radius(nx,ny,348.0/256.0);
                        if(q>=1 || ny>0.32)continue;
                        double cap=Math.Clamp((0.32-ny)/0.60,0,1);cap=cap*cap*(3-2*cap);
                        int i=py*348+px,p=result[i],alpha=(int)((uint)p>>24);
                        int a=(int)(255*cap+alpha*(1-cap));
                        int r=(int)(4*cap+((p>>16)&255)*(1-cap));
                        int g=(int)(6*cap+((p>>8)&255)*(1-cap));
                        int b=(int)(10*cap+(p&255)*(1-cap));
                        result[i]=a<<24|r<<16|g<<8|b;
                    }
                    if(previous!=null && !source.SequenceEqual(previous)) Interlocked.Increment(ref changed);
                    previous=source;
                    app.Dispatcher.BeginInvoke(new Action(()=>
                    {
                        bitmap.WritePixels(new Int32Rect(0,0,348,256),result,348*4,0);
                        count++; Interlocked.Exchange(ref pending,0);
                    }));
                };
                capture.Start();
            }
            catch(Exception ex) {File.AppendAllText(log,ex+Environment.NewLine);}
            var finish=new DispatcherTimer {Interval=TimeSpan.FromSeconds(20)};
            finish.Tick += delegate
            {
                finish.Stop(); move.Stop(); capture?.Dispose();
                File.AppendAllText(log,$"frames={count}; changed-background-frames={changed}; elapsed={clock.Elapsed.TotalSeconds:0.0}s\n");
                overlay.Close(); background.Close(); app.Shutdown();
            };
            finish.Start();
        };
        app.Run();
    }
    [StructLayout(LayoutKind.Sequential)]private struct RectPx {public int left,top,right,bottom;}
    [DllImport("dwmapi.dll")]private static extern int DwmGetWindowAttribute(IntPtr h,int attribute,out RectPx r,int size);
}
