using System.Diagnostics;
using System.IO.MemoryMappedFiles;
using System.Runtime.InteropServices;

namespace SiriAi;

internal static class MonitorBridge
{
    private sealed record Frame(int[] Pixels,int Width,int Height,int[] Bounds);
    internal static void Run(int parentId,string name)
    {
        using var parent=Process.GetProcessById(parentId);
        using var memory=MemoryMappedFile.OpenExisting(name);
        using var view=memory.CreateViewAccessor();
        using var mutex=Mutex.OpenExisting(name+"-lock");
        const int width=348,height=256;
        var optics=new LiquidGlassOptics(width,height);
        int[] source=new int[width*height],output=new int[source.Length];
        WindowCapture capture=null;IntPtr monitor=IntPtr.Zero;
        Frame latest=null,processed=null;int generation=0;
        try
        {
            while(!parent.HasExited)
            {
                int x,y,w,h,enabled;
                mutex.WaitOne();
                try{x=view.ReadInt32(0);y=view.ReadInt32(4);w=view.ReadInt32(8);h=view.ReadInt32(12);enabled=view.ReadInt32(16);}
                finally{mutex.ReleaseMutex();}
                if(enabled==0||w<1||h<1)
                {
                    capture?.Dispose();capture=null;monitor=IntPtr.Zero;latest=null;processed=null;
                    mutex.WaitOne();try{view.Write(20,0);}finally{mutex.ReleaseMutex();}
                    Thread.Sleep(16);continue;
                }
                IntPtr desired=MonitorFromPoint(new Point{x=x+w/2,y=y+h/2},2);
                if(capture==null||monitor!=desired)
                {
                    capture?.Dispose();latest=null;processed=null;monitor=desired;
                    capture=new WindowCapture(monitor,true);
                    var owned=capture;
                    capture.CropScreen=new[]{x,y,w,h};
                    capture.Frame+=(pixels,fw,fh)=>Volatile.Write(ref latest,new Frame(pixels,fw,fh,owned.PublishedBounds));
                    capture.Start();
                }
                Volatile.Write(ref capture.CropScreen,new[]{x,y,w,h});
                var frame=Volatile.Read(ref latest);
                if(frame!=null && !ReferenceEquals(frame,processed))
                {
                    var b=frame.Bounds;
                    bool complete=b[0]<=x && b[1]<=y && b[2]>=x+w && b[3]>=y+h;
                    if(complete)
                    {
                        for(int py=0;py<height;py++)for(int px=0;px<width;px++)
                        {
                            int sx=Math.Clamp((int)(x+(px+.5)*w/width)-b[0],0,frame.Width-1);
                            int sy=Math.Clamp((int)(y+(py+.5)*h/height)-b[1],0,frame.Height-1);
                            source[py*width+px]=frame.Pixels[sy*frame.Width+sx];
                        }
                        optics.Render(source,output);
                        mutex.WaitOne();
                        try{view.WriteArray(64,output,0,output.Length);view.Write(24,++generation);view.Write(20,1);}
                        finally{mutex.ReleaseMutex();}
                        processed=frame;
                    }
                }
                Thread.Sleep(4);
            }
        }
        finally{capture?.Dispose();}
    }
    [StructLayout(LayoutKind.Sequential)]private struct Point{public int x,y;}
    [DllImport("user32.dll")]private static extern IntPtr MonitorFromPoint(Point point,uint flags);
}
