using System.Runtime.InteropServices;
using Windows.Graphics.DirectX.Direct3D11;
using WinRT;

namespace SiriAi;

// Read back only the lens footprint. Never transfer a full 4K window through
// SoftwareBitmap/IBuffer/byte[]/int[] for a few hundred displayed pixels.
internal sealed unsafe class GpuReadback : IDisposable
{
    private readonly IntPtr device,context;
    private IntPtr staging;
    private int width,height;
    internal GpuReadback(IntPtr device,IntPtr context)
    { this.device=device;this.context=context;Marshal.AddRef(device);Marshal.AddRef(context); }
    internal int[] Read(IDirect3DSurface surface,int left,int top,int w,int h)
    {
        var access=surface.As<ISurfaceAccess>();
        Guid iid=new("6F15AAF2-D208-4E89-9AB4-489535D34F9C");
        access.GetInterface(in iid,out IntPtr texture);
        try
        {
            TextureDesc actual;
            ((delegate* unmanaged[Stdcall]<IntPtr,TextureDesc*,void>)(*(IntPtr**)texture)[10])(texture,&actual);
            if(left<0||top<0||w<=0||h<=0||left+w>actual.Width||top+h>actual.Height)
                throw new ArgumentOutOfRangeException("crop");
            if(staging==IntPtr.Zero||width!=w||height!=h)
            {
                if(staging!=IntPtr.Zero){Marshal.Release(staging);staging=IntPtr.Zero;}
                var desc=new TextureDesc {Width=(uint)w,Height=(uint)h,Mips=1,Array=1,Format=actual.Format,
                    SampleCount=1,Usage=3,CpuAccess=0x20000};
                IntPtr created;
                int hr=((delegate* unmanaged[Stdcall]<IntPtr,TextureDesc*,IntPtr,IntPtr*,int>)(*(IntPtr**)device)[5])(device,&desc,IntPtr.Zero,&created);
                Marshal.ThrowExceptionForHR(hr);staging=created;width=w;height=h;
            }
            var box=new Box{Left=(uint)left,Top=(uint)top,Right=(uint)(left+w),Bottom=(uint)(top+h),Back=1};
            ((delegate* unmanaged[Stdcall]<IntPtr,IntPtr,uint,uint,uint,uint,IntPtr,uint,Box*,void>)(*(IntPtr**)context)[46])
                (context,staging,0,0,0,0,texture,0,&box);
            Mapped map;
            int status=((delegate* unmanaged[Stdcall]<IntPtr,IntPtr,uint,uint,uint,Mapped*,int>)(*(IntPtr**)context)[14])
                (context,staging,0,1,0,&map);
            Marshal.ThrowExceptionForHR(status);
            try
            {
                int[] pixels=new int[w*h];
                for(int row=0;row<h;row++)Marshal.Copy(map.Data+(int)(row*map.RowPitch),pixels,row*w,w);
                return pixels;
            }
            finally{((delegate* unmanaged[Stdcall]<IntPtr,IntPtr,uint,void>)(*(IntPtr**)context)[15])(context,staging,0);}
        }
        finally{Marshal.Release(texture);}
    }
    public void Dispose(){if(staging!=IntPtr.Zero){Marshal.Release(staging);staging=IntPtr.Zero;}Marshal.Release(context);Marshal.Release(device);}
    [StructLayout(LayoutKind.Sequential)]private struct TextureDesc
    {public uint Width,Height,Mips,Array,Format,SampleCount,SampleQuality,Usage,Bind,CpuAccess,Misc;}
    [StructLayout(LayoutKind.Sequential)]private struct Box{public uint Left,Top,Front,Right,Bottom,Back;}
    [StructLayout(LayoutKind.Sequential)]private struct Mapped{public IntPtr Data;public uint RowPitch,DepthPitch;}
    [ComImport,Guid("A9B3D012-3DF2-4EE3-B8D1-8695F457D3C1"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface ISurfaceAccess{void GetInterface(in Guid iid,out IntPtr pointer);}
}
