using System.IO;
using Windows.Graphics.Capture;
using Windows.Security.Authorization.AppCapabilityAccess;

namespace SiriAi;

internal static class BorderlessCapture
{
    internal static bool Allowed { get; private set; }
    private static string StatusPath => Path.Combine(AppContext.BaseDirectory, "borderless-status.txt");
    internal static async Task RequestAsync()
    {
        try
        {
            var status = await GraphicsCaptureAccess.RequestAccessAsync(GraphicsCaptureAccessKind.Borderless);
            Allowed = status == AppCapabilityAccessStatus.Allowed;
            File.WriteAllText(StatusPath, DateTime.Now.ToString("O") + " " + status);
        }
        catch (Exception ex)
        {
            Allowed = false;
            File.WriteAllText(StatusPath, DateTime.Now.ToString("O") + " Error: " + ex);
        }
    }
    internal static void RestorePermission()
    {
        // A previous explicit request is required; never start a new consent
        // flow from an ordinary background launch without that user intent.
        if (!File.Exists(StatusPath) || !File.ReadAllText(StatusPath).TrimEnd().EndsWith(" Allowed")) return;
        Task.Run(RequestAsync).GetAwaiter().GetResult();
    }
}
