using System;

namespace SiriAi;

// Native counterpart of the liquid-glass skill's rounded-rectangle SDF map:
// frost the independent background, then sample it inward at the curved bezel.
internal sealed class PillGlassOptics
{
    internal readonly int Width;
    internal readonly int Height;
    internal readonly float[] OffsetX;
    internal readonly float[] OffsetY;
    internal readonly byte[] Coverage;
    private readonly int[] horizontal;
    private readonly int[] vertical;
    private readonly int[] softened;
    private readonly int blurRadius;

    internal PillGlassOptics(int width, int height)
    {
        if (width < 32 || height < 16) throw new ArgumentOutOfRangeException(nameof(width));
        Width = width;
        Height = height;
        OffsetX = new float[width * height];
        OffsetY = new float[width * height];
        Coverage = new byte[width * height];
        horizontal = new int[width * height];
        vertical = new int[width * height];
        softened = new int[width * height];
        blurRadius = Math.Max(3, Math.Min(6, height / 15));
        double radius = height * 0.5;
        double halfWidth = width * 0.5;
        double halfHeight = height * 0.5;
        double straight = Math.Max(0.0, halfWidth - radius);
        double bezel = Math.Min(24.0, height * 0.35);
        for (int y = 0; y < height; y++)
        for (int x = 0; x < width; x++)
        {
            int i = y * width + x;
            double px = x + 0.5 - halfWidth;
            double py = y + 0.5 - halfHeight;
            double qx = Math.Abs(px) - straight;
            double qy = Math.Abs(py);
            // A true stadium SDF: straight top/bottom, semicircular ends.
            double distance = Math.Sqrt(Math.Max(qx, 0) * Math.Max(qx, 0) + qy * qy) - radius;
            double depth = -distance;
            Coverage[i] = (byte)Math.Round(255.0 * Smooth(depth + 0.35));
            if (depth <= 0 || depth >= bezel) continue;
            double edge = 1.0 - Smooth(depth / bezel);
            // Smooth convex profile: an edge-only displacement, neutral center.
            double magnitude = 13.0 * edge * edge * (3.0 - 2.0 * edge);
            double nx, ny;
            if (qx > 0)
            {
                double length = Math.Sqrt(qx * qx + qy * qy);
                nx = Math.Sign(px) * qx / Math.Max(0.0001, length);
                ny = Math.Sign(py) * qy / Math.Max(0.0001, length);
            }
            else
            {
                nx = 0.0;
                ny = Math.Sign(py);
            }
            OffsetX[i] = (float)(-nx * magnitude);
            OffsetY[i] = (float)(-ny * magnitude);
        }
    }

    internal void Render(int[] background, int[] destination)
    {
        if (background.Length != Width * Height || destination.Length != background.Length)
            throw new ArgumentException("Pill frame dimensions changed.");
        BlurHorizontal(background, horizontal);
        BlurVertical(horizontal, vertical);
        BlurHorizontal(vertical, horizontal);
        BlurVertical(horizontal, softened);
        for (int y = 0; y < Height; y++)
        for (int x = 0; x < Width; x++)
        {
            int i = y * Width + x;
            int alpha = Coverage[i];
            if (alpha == 0) { destination[i] = 0; continue; }
            // Slightly different wavelength paths provide restrained dispersion.
            int red = Sample(softened, x + OffsetX[i] * 0.94, y + OffsetY[i] * 0.94, 16);
            int green = Sample(softened, x + OffsetX[i], y + OffsetY[i], 8);
            int blue = Sample(softened, x + OffsetX[i] * 1.06, y + OffsetY[i] * 1.06, 0);
            destination[i] = (alpha << 24) | (red << 16) | (green << 8) | blue;
        }
    }

    private void BlurHorizontal(int[] source, int[] target)
    {
        int r = blurRadius;
        for (int y = 0; y < Height; y++)
        {
            int row = y * Width;
            int red = 0, green = 0, blue = 0;
            for (int k = -r; k <= r; k++)
            {
                int p = source[row + Math.Clamp(k, 0, Width - 1)];
                red += (p >> 16) & 255; green += (p >> 8) & 255; blue += p & 255;
            }
            int divisor = r * 2 + 1;
            for (int x = 0; x < Width; x++)
            {
                target[row + x] = unchecked((int)0xff000000) |
                    ((red / divisor) << 16) | ((green / divisor) << 8) | (blue / divisor);
                int leaving = source[row + Math.Clamp(x - r, 0, Width - 1)];
                int entering = source[row + Math.Clamp(x + r + 1, 0, Width - 1)];
                red += ((entering >> 16) & 255) - ((leaving >> 16) & 255);
                green += ((entering >> 8) & 255) - ((leaving >> 8) & 255);
                blue += (entering & 255) - (leaving & 255);
            }
        }
    }

    private void BlurVertical(int[] source, int[] target)
    {
        int r = blurRadius;
        for (int x = 0; x < Width; x++)
        {
            int red = 0, green = 0, blue = 0;
            for (int k = -r; k <= r; k++)
            {
                int p = source[Math.Clamp(k, 0, Height - 1) * Width + x];
                red += (p >> 16) & 255; green += (p >> 8) & 255; blue += p & 255;
            }
            int divisor = r * 2 + 1;
            for (int y = 0; y < Height; y++)
            {
                target[y * Width + x] = unchecked((int)0xff000000) |
                    ((red / divisor) << 16) | ((green / divisor) << 8) | (blue / divisor);
                int leaving = source[Math.Clamp(y - r, 0, Height - 1) * Width + x];
                int entering = source[Math.Clamp(y + r + 1, 0, Height - 1) * Width + x];
                red += ((entering >> 16) & 255) - ((leaving >> 16) & 255);
                green += ((entering >> 8) & 255) - ((leaving >> 8) & 255);
                blue += (entering & 255) - (leaving & 255);
            }
        }
    }

    private int Sample(int[] source, double x, double y, int shift)
    {
        x = Math.Clamp(x, 0.0, Width - 1.00001);
        y = Math.Clamp(y, 0.0, Height - 1.00001);
        int ix = (int)x, iy = (int)y;
        double fx = x - ix, fy = y - iy;
        int i = iy * Width + ix;
        double top = ((source[i] >> shift) & 255) * (1 - fx) + ((source[i + 1] >> shift) & 255) * fx;
        double bottom = ((source[i + Width] >> shift) & 255) * (1 - fx) + ((source[i + Width + 1] >> shift) & 255) * fx;
        return (int)Math.Round(top * (1 - fy) + bottom * fy);
    }

    private static double Smooth(double t)
    {
        t = Math.Clamp(t, 0.0, 1.0);
        return t * t * (3.0 - 2.0 * t);
    }
}
