using System;
using LiquidGlassWpf;

namespace SiriAi
{
    // Live-capture adapter for LiquidGlassWpf.cs. The supplied WPF renderer is
    // the source of the SDF, lens curve, defaults and composition model. This
    // adapter caches shape-only values and mip buffers for continuous capture.
    internal sealed class LiquidGlassOptics
    {
        internal readonly int Width, Height;
        internal readonly float[] OffsetX, OffsetY;
        internal readonly byte[] Coverage;
        private readonly GlassShape _shape;
        private readonly GlassOptions _options = new GlassOptions();
        private readonly float[] _normalX, _normalY, _lod, _bleed, _highlight, _face, _edge;
        private readonly int[][] _mips;
        private readonly int[] _mipWidths, _mipHeights;
        private readonly GpuLiquidGlassOptics _gpu;

        internal LiquidGlassOptics(int width, int height)
        {
            if (width < 2 || height < 2) throw new ArgumentOutOfRangeException("width");
            Width = width; Height = height;
            _shape = new GlassShape((width - 1) * 0.5, (height - 1) * 0.5,
                width - 1, height - 1, (height - 1) * 0.5);
            int count = checked(width * height);
            OffsetX = new float[count]; OffsetY = new float[count]; Coverage = new byte[count];
            _normalX = new float[count]; _normalY = new float[count]; _lod = new float[count];
            _bleed = new float[count]; _highlight = new float[count]; _face = new float[count];
            _edge = new float[count];
            double lightLength = Math.Sqrt(_options.LightDirection[0] * _options.LightDirection[0] +
                _options.LightDirection[1] * _options.LightDirection[1]);
            if (lightLength < 1e-9) lightLength = 1;
            double lightX = _options.LightDirection[0] / lightLength;
            double lightY = _options.LightDirection[1] / lightLength;
            for (int y = 0; y < height; y++) for (int x = 0; x < width; x++)
            {
                int i = y * width + x;
                double d = LiquidGlassRenderer.RoundedRectSdf(x + 0.5, y + 0.5, _shape);
                double face = Saturate(0.5 - d);
                if (face <= 0) continue;
                double gx = LiquidGlassRenderer.RoundedRectSdf(x + 1.0, y + 0.5, _shape) -
                    LiquidGlassRenderer.RoundedRectSdf(x, y + 0.5, _shape);
                double gy = LiquidGlassRenderer.RoundedRectSdf(x + 0.5, y + 1.0, _shape) -
                    LiquidGlassRenderer.RoundedRectSdf(x + 0.5, y, _shape);
                double length = Math.Sqrt(gx * gx + gy * gy);
                if (length > 1e-6) { gx /= length; gy /= length; } else { gx = 0; gy = -1; }
                double mx = _options.DisplacementMatrix[0] * gx + _options.DisplacementMatrix[1] * gy;
                double my = _options.DisplacementMatrix[2] * gx + _options.DisplacementMatrix[3] * gy;
                double inner = _options.InnerRefractionAmount * LiquidGlassRenderer.LensFalloff(d,
                    1 / Math.Max(_options.InnerRefractionHeight, 0.001));
                double outer = _options.OuterRefractionAmount * LiquidGlassRenderer.LensFalloff(d,
                    1 / Math.Max(_options.OuterRefractionHeight, 0.001));
                double threshold = _options.RefractionThreshold1 - _options.RefractionThreshold0;
                double outerWeight = Saturate((d - _options.RefractionThreshold0) /
                    (Math.Abs(threshold) < 1e-6 ? 1e-6 : threshold)) * _options.RefractionOpacity;
                double shift = Mix(inner, outer, outerWeight);
                double edge = LiquidGlassRenderer.LensFalloff(d,
                    1 / Math.Max(_options.InnerRefractionHeight, 0.001));
                double radius = Math.Max(1, _options.BlurRadius + _options.BlurEdgeRadius * edge);
                double rim = Math.Exp(-Math.Pow(d / Math.Max(_options.HighlightWidth, 0.001), 2));
                double facing = Math.Max(0, gx * lightX + gy * lightY);
                _normalX[i] = (float)mx; _normalY[i] = (float)my;
                OffsetX[i] = (float)(mx * shift); OffsetY[i] = (float)(my * shift);
                _lod[i] = (float)Math.Max(0, Math.Log(radius, 2));
                _bleed[i] = (float)(_options.EdgeBleedAmount * Math.Exp(-Math.Abs(d) /
                    Math.Max(_options.EdgeBleedWidth, 0.001)));
                _highlight[i] = (float)(_options.HighlightAmount * rim * (0.3 + 0.7 * facing));
                _face[i] = (float)face; _edge[i] = (float)edge;
                Coverage[i] = (byte)Math.Round(255 * face);
            }
            int levels = 1, w = width, h = height;
            while ((w > 1 || h > 1) && levels < 9)
            { w = Math.Max(1, (w + 1) / 2); h = Math.Max(1, (h + 1) / 2); levels++; }
            _mips = new int[levels][]; _mipWidths = new int[levels]; _mipHeights = new int[levels];
            w = width; h = height;
            for (int level = 0; level < levels; level++)
            {
                _mipWidths[level] = w; _mipHeights[level] = h;
                _mips[level] = new int[checked(w * h)];
                w = Math.Max(1, (w + 1) / 2); h = Math.Max(1, (h + 1) / 2);
            }
            try { _gpu = new GpuLiquidGlassOptics(width, height, OffsetX, OffsetY,
                _normalX, _normalY, _face, _edge, _highlight); }
            catch (Exception ex)
            {
                _gpu = null;
                System.IO.File.AppendAllText(System.IO.Path.Combine(AppContext.BaseDirectory, "gpu-render.log"),
                    $"{DateTimeOffset.Now:O} backend=CPU reason={ex}{Environment.NewLine}");
            }
        }

        internal void Render(int[] background, int[] destination)
        {
            if (background == null || destination == null || background.Length != Width * Height ||
                destination.Length != background.Length)
                throw new ArgumentException("Background must match the optical map dimensions.");
            if (ReferenceEquals(background, destination))
                throw new ArgumentException("Refraction requires separate input and output buffers.");
            if (_gpu != null)
            {
                try { _gpu.Render(background, destination, Width, Height); return; }
                catch (Exception ex)
                {
                    System.IO.File.AppendAllText(System.IO.Path.Combine(AppContext.BaseDirectory, "gpu-render.log"),
                        $"{DateTimeOffset.Now:O} dispatch=fallback reason={ex.Message}{Environment.NewLine}");
                }
            }
            BuildMipChain(background);
            for (int y = 0; y < Height; y++) for (int x = 0; x < Width; x++)
            {
                int i = y * Width + x;
                double face = _face[i];
                if (face <= 0) { destination[i] = 0; continue; }
                double mx = _normalX[i], my = _normalY[i];
                double sx = x + OffsetX[i], sy = y + OffsetY[i], lod = _lod[i];
                double amount = _options.AberrationAmount * _edge[i];
                double red = DispersionChannel(sx, sy, -my, mx, amount, lod, 16, 1, 3);
                double green = DispersionChannel(sx, sy, -my, mx, amount, lod, 8, -1, 1);
                double blue = DispersionChannel(sx, sy, -my, mx, amount, lod, 0, -3, -1);
                double mr = _options.FaceColorMatrix[0] * red + _options.FaceColorMatrix[1] * green +
                    _options.FaceColorMatrix[2] * blue + _options.FaceColorMatrix[3] * 255;
                double mg = _options.FaceColorMatrix[4] * red + _options.FaceColorMatrix[5] * green +
                    _options.FaceColorMatrix[6] * blue + _options.FaceColorMatrix[7] * 255;
                double mb = _options.FaceColorMatrix[8] * red + _options.FaceColorMatrix[9] * green +
                    _options.FaceColorMatrix[10] * blue + _options.FaceColorMatrix[11] * 255;
                double bleed = _bleed[i];
                if (bleed > 0.001)
                {
                    double bx = x + mx * _options.EdgeBleedWidth * 0.45;
                    double by = y + my * _options.EdgeBleedWidth * 0.45;
                    mr = Mix(mr, SampleLodChannel(bx, by, lod + 1, 16), bleed);
                    mg = Mix(mg, SampleLodChannel(bx, by, lod + 1, 8), bleed);
                    mb = Mix(mb, SampleLodChannel(bx, by, lod + 1, 0), bleed);
                }
                double highlight = _highlight[i];
                mr = Mix(Mix(mr, _options.Tint[0], _options.TintAmount), 255, highlight);
                mg = Mix(Mix(mg, _options.Tint[1], _options.TintAmount), 255, highlight);
                mb = Mix(Mix(mb, _options.Tint[2], _options.TintAmount), 255, highlight);
                int original = background[i];
                double opacity = face * _options.FaceOpacity;
                mr = Mix((original >> 16) & 255, mr, opacity);
                mg = Mix((original >> 8) & 255, mg, opacity);
                mb = Mix(original & 255, mb, opacity);
                int alpha = ByteValue(opacity * 255);
                destination[i] = (alpha << 24) | (ByteValue(mr) << 16) |
                    (ByteValue(mg) << 8) | ByteValue(mb);
            }
        }

        private double DispersionChannel(double x, double y, double tx, double ty,
            double amount, double lod, int shift, int firstTap, int lastTap)
        {
            if (amount <= 0.001) return SampleLodChannel(x, y, lod, shift);
            double sum = 0; int count = 0;
            for (int tap = firstTap; tap <= lastTap; tap++)
            {
                sum += SampleLodChannel(x + tx * amount * tap / 3.0,
                    y + ty * amount * tap / 3.0, lod, shift);
                count++;
            }
            return sum / count;
        }

        private double SampleLodChannel(double x, double y, double lod, int shift)
        {
            double level = Clamp(lod, 0, _mips.Length - 1);
            int low = (int)Math.Floor(level), high = Math.Min(low + 1, _mips.Length - 1);
            double a = BilinearChannel(low, x, y, shift);
            return low == high ? a : Mix(a, BilinearChannel(high, x, y, shift), level - low);
        }

        private double BilinearChannel(int level, double x, double y, int shift)
        {
            int width = _mipWidths[level], height = _mipHeights[level];
            double px = Clamp((x + 0.5) * width / Width - 0.5, 0, width - 1);
            double py = Clamp((y + 0.5) * height / Height - 0.5, 0, height - 1);
            int x0 = (int)Math.Floor(px), y0 = (int)Math.Floor(py);
            int x1 = Math.Min(x0 + 1, width - 1), y1 = Math.Min(y0 + 1, height - 1);
            double tx = px - x0, ty = py - y0;
            int[] data = _mips[level];
            double a = Mix((data[y0 * width + x0] >> shift) & 255,
                (data[y0 * width + x1] >> shift) & 255, tx);
            double b = Mix((data[y1 * width + x0] >> shift) & 255,
                (data[y1 * width + x1] >> shift) & 255, tx);
            return Mix(a, b, ty);
        }

        private void BuildMipChain(int[] source)
        {
            Array.Copy(source, _mips[0], source.Length);
            for (int level = 1; level < _mips.Length; level++)
            {
                int[] parent = _mips[level - 1], data = _mips[level];
                int pw = _mipWidths[level - 1], ph = _mipHeights[level - 1];
                int width = _mipWidths[level], height = _mipHeights[level];
                for (int y = 0; y < height; y++) for (int x = 0; x < width; x++)
                {
                    int sa = 0, sr = 0, sg = 0, sb = 0, count = 0;
                    for (int yy = 0; yy < 2; yy++) for (int xx = 0; xx < 2; xx++)
                    {
                        int sx = x * 2 + xx, sy = y * 2 + yy;
                        if (sx >= pw || sy >= ph) continue;
                        int p = parent[sy * pw + sx];
                        sa += (int)((uint)p >> 24); sr += (p >> 16) & 255;
                        sg += (p >> 8) & 255; sb += p & 255; count++;
                    }
                    data[y * width + x] = (sa / count << 24) | (sr / count << 16) |
                        (sg / count << 8) | (sb / count);
                }
            }
        }

        private static int ByteValue(double value)
        { return (int)Math.Round(Clamp(value, 0, 255), MidpointRounding.ToEven); }
        private static double Clamp(double value, double low, double high)
        { return Math.Max(low, Math.Min(high, value)); }
        private static double Saturate(double value) { return Clamp(value, 0, 1); }
        private static double Mix(double a, double b, double t) { return a + (b - a) * t; }
    }
}
