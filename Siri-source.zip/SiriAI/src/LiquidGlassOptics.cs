using System;

namespace SiriAi
{
    // Native equivalent of the liquid-glass skill's displacement + RGB passes.
    // Input must be an independent, current background frame, never a screenshot
    // containing this overlay. The optical map is immutable between size changes.
    internal sealed class LiquidGlassOptics
    {
        internal readonly int Width, Height;
        internal readonly float[] OffsetX, OffsetY;
        internal readonly byte[] Coverage;

        internal LiquidGlassOptics(int width, int height)
        {
            if (width < 2 || height < 2) throw new ArgumentOutOfRangeException("width");
            Width = width; Height = height;
            OffsetX = new float[width * height];
            OffsetY = new float[width * height];
            Coverage = new byte[width * height];
            double ax = (width - 1) * 0.5, ay = (height - 1) * 0.5;
            double bezel = Math.Min(width, height) * 0.24;
            for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++)
            {
                int i = y * width + x;
                double nx = (x - ax) / ax, ny = (y - ay) / ay;
                double aspect = width / (double)height;
                double q = GlassContour.Radius(nx, ny, aspect);
                if (q >= 1.0) continue;
                // Gradient in physical pixel coordinates, not a circular radial
                // vector stretched afterward: normals follow the wide silhouette.
                double gx = Math.Sign(nx) * Math.Max(0.0, Math.Abs(nx) * aspect - (aspect - 1.0));
                double gy = ny;
                double length = Math.Sqrt(gx * gx + gy * gy);
                double depth = (1.0 - q) * ay;
                double lower = Smooth((ny + 0.40) / 0.60);
                // Replacement, not a translucent duplicate of the background.
                // The lower interior is fully covered by its refracted sample.
                // Only the outer pixel and the cap junction are antialiased.
                double coverage = Smooth((ny + 0.40) / 0.10);
                Coverage[i] = (byte)Math.Round(255.0 * Smooth(depth / 0.8) * coverage);
                if (length < 1e-9 || lower == 0) continue;
                double d = Math.Max(0.002, Math.Min(1.0, depth / bezel));
                // Convex squircle profile h(d)=(1-(1-d)^4)^(1/4).
                // Snell: air/glass = 1/1.5. A ray entering a steeper bezel
                // travels farther inward; the flat interior stays undisturbed.
                double a = 1.0 - d;
                double slope = a * a * a / Math.Pow(Math.Max(1e-9, 1.0 - a*a*a*a), 0.75);
                double incident = Math.Atan(slope);
                double refracted = Math.Asin(Math.Sin(incident) / 1.5);
                double magnitude = Math.Tan(incident - refracted) * bezel * 0.18;
                magnitude *= lower;
                // The Siri body is a thick lens, not a flat card with a bezel.
                // Its whole lower volume magnifies the source. A continuous
                // curved interior is combined with the stronger perimeter term.
                double bodyCurve = 0.30 + 0.20 * Math.Min(1.0, q * q);
                double bodyX = -nx * ax * bodyCurve * lower;
                double bodyY = -(ny - 0.35) * ay * bodyCurve * lower;
                OffsetX[i] = (float)(bodyX - gx / length * magnitude);
                OffsetY[i] = (float)(bodyY - gy / length * magnitude);
            }
        }

        internal void Render(int[] background, int[] destination)
        {
            if (background == null || destination == null || background.Length != Width * Height || destination.Length != background.Length)
                throw new ArgumentException("Background must match the optical map dimensions.");
            if (ReferenceEquals(background, destination)) throw new ArgumentException("Refraction requires separate input and output buffers.");
            for (int y = 0; y < Height; y++)
            for (int x = 0; x < Width; x++)
            {
                int i = y * Width + x, alpha = Coverage[i];
                if (alpha == 0) { destination[i] = 0; continue; }
                // Restrained wavelength separation, not colored decorative rims.
                int red = Sample(background, x + OffsetX[i] * 0.97, y + OffsetY[i] * 0.97, 16);
                int green = Sample(background, x + OffsetX[i], y + OffsetY[i], 8);
                int blue = Sample(background, x + OffsetX[i] * 1.03, y + OffsetY[i] * 1.03, 0);
                destination[i] = (alpha << 24) | (red << 16) | (green << 8) | blue;
            }
        }

        private int Sample(int[] source, double x, double y, int shift)
        {
            x = Math.Max(0, Math.Min(Width - 1.00001, x));
            y = Math.Max(0, Math.Min(Height - 1.00001, y));
            int ix = (int)x, iy = (int)y;
            double fx = x - ix, fy = y - iy;
            int i = iy * Width + ix;
            double top = ((source[i] >> shift) & 255) * (1-fx) + ((source[i+1] >> shift) & 255) * fx;
            double bottom = ((source[i+Width] >> shift) & 255) * (1-fx) + ((source[i+Width+1] >> shift) & 255) * fx;
            return (int)Math.Round(top * (1-fy) + bottom * fy);
        }

        private static double Smooth(double value)
        {
            value = Math.Max(0, Math.Min(1, value));
            return value * value * (3 - 2 * value);
        }
    }
}
