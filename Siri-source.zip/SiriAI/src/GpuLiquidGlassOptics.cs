using System;
using System.Linq;
using System.IO;
using ComputeSharp;

namespace SiriAi;

/// <summary>DirectX 12 liquid-glass compositor pinned to the NVIDIA adapter.</summary>
internal sealed partial class GpuLiquidGlassOptics : IDisposable
{
    private readonly GraphicsDevice device;
    private readonly ReadWriteBuffer<int> source, output;
    private readonly ReadOnlyBuffer<float> offsetX, offsetY, normalX, normalY, face, edge, highlight;
    private bool rendered;
    internal string AdapterName => device.Name;

    internal GpuLiquidGlassOptics(int width, int height, float[] ox, float[] oy,
        float[] nx, float[] ny, float[] f, float[] e, float[] hi)
    {
        device = GraphicsDevice.EnumerateDevices().FirstOrDefault(d =>
            d.IsHardwareAccelerated && d.Name.Contains("NVIDIA", StringComparison.OrdinalIgnoreCase))
            ?? throw new InvalidOperationException("NVIDIA DirectX 12 adapter was not found.");
        int count = checked(width * height);
        source = device.AllocateReadWriteBuffer<int>(count);
        output = device.AllocateReadWriteBuffer<int>(count);
        offsetX = device.AllocateReadOnlyBuffer(ox); offsetY = device.AllocateReadOnlyBuffer(oy);
        normalX = device.AllocateReadOnlyBuffer(nx); normalY = device.AllocateReadOnlyBuffer(ny);
        face = device.AllocateReadOnlyBuffer(f); edge = device.AllocateReadOnlyBuffer(e);
        highlight = device.AllocateReadOnlyBuffer(hi);
        File.AppendAllText(Path.Combine(AppContext.BaseDirectory, "gpu-render.log"),
            $"{DateTimeOffset.Now:O} backend=DirectX12 adapter={device.Name} size={width}x{height}{Environment.NewLine}");
    }

    internal void Render(int[] input, int[] destination, int width, int height)
    {
        source.CopyFrom(input);
        device.For(width, height, new LiquidGlassShader(source, output, offsetX, offsetY,
            normalX, normalY, face, edge, highlight, width, height));
        output.CopyTo(destination);
        if (!rendered)
        {
            rendered = true;
            File.AppendAllText(Path.Combine(AppContext.BaseDirectory, "gpu-render.log"),
                $"{DateTimeOffset.Now:O} dispatch=success adapter={device.Name}{Environment.NewLine}");
        }
    }

    public void Dispose()
    {
        highlight.Dispose(); edge.Dispose(); face.Dispose(); normalY.Dispose(); normalX.Dispose();
        offsetY.Dispose(); offsetX.Dispose(); output.Dispose(); source.Dispose();
    }

    [ThreadGroupSize(DefaultThreadGroupSizes.XY)]
    [GeneratedComputeShaderDescriptor]
    internal readonly partial struct LiquidGlassShader : IComputeShader
    {
        private readonly ReadWriteBuffer<int> source, output;
        private readonly ReadOnlyBuffer<float> offsetX, offsetY, normalX, normalY, face, edge, highlight;
        private readonly int width, height;

        public LiquidGlassShader(ReadWriteBuffer<int> source, ReadWriteBuffer<int> output,
            ReadOnlyBuffer<float> offsetX, ReadOnlyBuffer<float> offsetY,
            ReadOnlyBuffer<float> normalX, ReadOnlyBuffer<float> normalY,
            ReadOnlyBuffer<float> face, ReadOnlyBuffer<float> edge,
            ReadOnlyBuffer<float> highlight, int width, int height)
        {
            this.source = source; this.output = output; this.offsetX = offsetX; this.offsetY = offsetY;
            this.normalX = normalX; this.normalY = normalY; this.face = face; this.edge = edge;
            this.highlight = highlight; this.width = width; this.height = height;
        }

        public void Execute()
        {
            int x = ThreadIds.X, y = ThreadIds.Y, i = y * width + x;
            float opacity = face[i] * 0.98f;
            if (opacity <= 0f) { output[i] = 0; return; }
            float sx = x + offsetX[i], sy = y + offsetY[i];
            float tx = -normalY[i], ty = normalX[i];
            float amount = 3.5f * edge[i];
            float r = 0f, g = 0f, b = 0f;
            for (int tap = 1; tap <= 3; tap++)
            {
                int p = Sample(sx + tx * amount * tap / 3f, sy + ty * amount * tap / 3f);
                r += (p >> 16) & 255;
            }
            for (int tap = -1; tap <= 1; tap++)
            {
                int p = Sample(sx + tx * amount * tap / 3f, sy + ty * amount * tap / 3f);
                g += (p >> 8) & 255;
            }
            for (int tap = -3; tap <= -1; tap++)
            {
                int p = Sample(sx + tx * amount * tap / 3f, sy + ty * amount * tap / 3f);
                b += p & 255;
            }
            r /= 3f; g /= 3f; b /= 3f;
            float lit = highlight[i];
            r = Hlsl.Lerp(Hlsl.Lerp(r, 255f, 0.035f), 255f, lit);
            g = Hlsl.Lerp(Hlsl.Lerp(g, 255f, 0.035f), 255f, lit);
            b = Hlsl.Lerp(Hlsl.Lerp(b, 255f, 0.035f), 255f, lit);
            int original = source[i];
            r = Hlsl.Lerp((original >> 16) & 255, r, opacity);
            g = Hlsl.Lerp((original >> 8) & 255, g, opacity);
            b = Hlsl.Lerp(original & 255, b, opacity);
            int a = (int)(Hlsl.Saturate(opacity) * 255f + 0.5f);
            output[i] = (a << 24) | ((int)Hlsl.Clamp(r, 0f, 255f) << 16) |
                ((int)Hlsl.Clamp(g, 0f, 255f) << 8) | (int)Hlsl.Clamp(b, 0f, 255f);
        }

        private int Sample(float px, float py)
        {
            int ix = (int)Hlsl.Clamp(px + 0.5f, 0f, width - 1f);
            int iy = (int)Hlsl.Clamp(py + 0.5f, 0f, height - 1f);
            return source[iy * width + ix];
        }
    }
}
